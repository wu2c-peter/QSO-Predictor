
# QSO Predictor
# Copyright (C) 2025 [Peter Hirst/WU2C]
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.



import threading
import time
from psk_client import PskReporterClient

class QSOAnalyzer:
    def __init__(self, config):
        self.config = config
        self.psk = PskReporterClient()
        self.my_call = config.get('ANALYSIS', 'my_callsign', fallback='N0CALL')
        self.current_dial_freq = 0
        
        # The Master Cache: { 'SENDER_CALL': [List of Spots they heard] }
        self.band_cache = {}
        self.last_bulk_update = 0
        
        self.running = True
        self.worker_thread = threading.Thread(target=self._bulk_update_loop, daemon=True)
        self.worker_thread.start()

    def set_dial_freq(self, freq):
        # If we change bands, we need to clear cache and update immediately
        if self.current_dial_freq != freq:
            self.current_dial_freq = freq
            self.band_cache.clear()
            self.last_bulk_update = 0 # Force immediate update

    def analyze_decode(self, decode_data, update_callback=None, priority=5):
        # 1. Immediate Local Prob
        snr = decode_data['snr']
        if snr >= -1: prob = 45
        elif snr >= -10: prob = 35
        elif snr >= -15: prob = 25
        else: prob = 15
        
        decode_data['prob'] = f"{prob}%"
        decode_data['competition'] = "..."
        if 'rec_offset' not in decode_data: decode_data['rec_offset'] = decode_data['freq']

        # 2. INSTANT LOOKUP (No Queue!)
        if decode_data['call'] and update_callback:
            # We run this in a thread just to keep the UI snappy, 
            # even though the lookup is now instant from memory.
            threading.Thread(target=self._perform_lookup, 
                             args=(decode_data, update_callback)).start()
        
        return decode_data

    def _bulk_update_loop(self):
        """Runs every 2 minutes to fetch data for the ENTIRE band."""
        while self.running:
            if self.current_dial_freq > 0:
                print(f"DEBUG: Performing Bulk Query for {self.current_dial_freq}...")
                
                # Query range: Dial to Dial+4kHz
                start_f = self.current_dial_freq
                end_f = self.current_dial_freq + 4000
                
                # Fetch ALL reports for this band
                reports = self.psk.get_band_reports(start_f, end_f)
                
                if reports is not None:
                    # Organize by Sender
                    new_cache = {}
                    for rep in reports:
                        sender = rep['sender'] # We need to ensure client returns this
                        if sender not in new_cache:
                            new_cache[sender] = []
                        new_cache[sender].append(rep)
                    
                    self.band_cache = new_cache
                    print(f"DEBUG: Bulk Update Complete. Cached {len(new_cache)} stations.")
                else:
                    print("DEBUG: Bulk Update Failed (Network/Rate Limit)")
            
            # Sleep 2 minutes (120 seconds)
            # PSK data doesn't change faster than that anyway.
            for _ in range(120):
                if not self.running: break
                time.sleep(1)

    def _perform_lookup(self, decode_data, callback):
        target_call = decode_data['call']
        
        # INSTANT CACHE LOOKUP
        # We handle callsign variants (e.g. K1ABC/P)
        heard_reports = []
        
        # Exact match
        if target_call in self.band_cache:
            heard_reports = self.band_cache[target_call]
        else:
            # Fuzzy match (if cache has K1ABC/P but target is K1ABC)
            # This is O(N) scan but cache keys are small (active stations only)
            for cached_call in self.band_cache:
                if target_call in cached_call or cached_call in target_call:
                    heard_reports = self.band_cache[cached_call]
                    break
        
        # Scoring Logic (Same as before)
        count = len(heard_reports)
        
        # If cache is empty but we just started, we might show "..."
        # But here we show "No Spots" if they aren't in the bulk list.
        
        remote_qrm_offsets = []
        if self.current_dial_freq > 0:
            for rep in heard_reports:
                try:
                    rep_freq = float(rep['freq']) 
                    offset = rep_freq - self.current_dial_freq
                    if 0 < offset < 3000:
                        remote_qrm_offsets.append(int(offset))
                except: pass
        
        decode_data['remote_qrm'] = remote_qrm_offsets

        current_prob = int(decode_data['prob'].replace('%',''))
        pileup_penalty = 0
        comp_str = "..."
        
        if count > 40: 
            pileup_penalty = -20; comp_str = "Pileup"
        elif count > 20: 
            pileup_penalty = -10; comp_str = "High"
        elif count > 10: 
            comp_str = "Med"
        elif count > 0:
            comp_str = "Low"
        else:
            comp_str = "No Spots"
            pileup_penalty = -5

        geo_bonus = 0
        direct_hit = False
        
        for rep in heard_reports:
            # Check receiver call (who they heard)
            if 'call' in rep and self.my_call in rep['call']:
                geo_bonus = 100; direct_hit = True; comp_str = "CONNECTED"
                break
        
        if not direct_hit:
            if count > 0:
                geo_bonus += 10
                if decode_data['snr'] > -10: geo_bonus += 15
            else:
                geo_bonus -= 20

        final_prob = max(5, min(99, current_prob + geo_bonus + pileup_penalty))
        decode_data['prob'] = f"{final_prob}%"
        decode_data['competition'] = comp_str
        
        callback(decode_data)


