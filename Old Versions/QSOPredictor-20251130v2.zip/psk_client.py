# QSO Predictor
# Copyright (C) 2025 [Peter Hirst/WU2C]
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.


import requests
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import re

class PskReporterClient:
    BASE_URL = "https://retrieve.pskreporter.info/query"
    HEADERS = {
        'User-Agent': 'QSO-Predictor-App/1.0 (Amateur Radio Tool)',
        'Accept': 'application/xml'
    }

    def __init__(self):
        self.cache = {}

    def get_what_station_hears(self, callsign):
        # Legacy method fallback
        return []

    def get_band_reports(self, start_freq, end_freq):
        """
        Fetches ALL reports for a frequency range (Hz).
        Example: 14074000 to 14078000
        """
        # Create freq range string: "14074000-14078000"
        frange = f"{int(start_freq)}-{int(end_freq)}"
        
        params = {
            'frange': frange,
            'flowStartSeconds': '-600', # Last 10 minutes
            'rronly': '1'
        }
        
        try:
            response = requests.get(self.BASE_URL, params=params, headers=self.HEADERS, timeout=15)
            
            if response.status_code == 200:
                return self._parse_bulk_xml(response.content)
            else:
                print(f"PSK Error {response.status_code}")
                return None
                
        except Exception as e:
            print(f"PSK Network Error: {e}")
            return None

    def _parse_bulk_xml(self, xml_content):
        results = []
        try:
            root = ET.fromstring(xml_content)
            for child in root:
                if child.tag == 'receptionReport':
                    sender = child.attrib.get('senderCallsign')
                    receiver = child.attrib.get('receiverCallsign')
                    snr = child.attrib.get('sNR')
                    freq = child.attrib.get('frequency')
                    
                    if sender and receiver:
                        results.append({
                            'sender': self._clean_callsign(sender),
                            'call': receiver, # Who they heard
                            'snr': int(snr) if snr else -99,
                            'freq': freq
                        })
        except: pass
        return results

    def _clean_callsign(self, call):
        if not call: return None
        match = re.search(r"([A-Z0-9/]+)", call)
        if match:
            c = match.group(1)
            if '/' in c: c = max(c.split('/'), key=len)
            return c
        return None


